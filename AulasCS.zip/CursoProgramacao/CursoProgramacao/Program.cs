﻿using CursoProgramacao;
using System.Runtime.Serialization;

partial class Program
{
    static void Main(string[] args)
    {
        /* Aula1 carlos = new Aula1();
        carlos.Dividir(); */

        Aula2 numeroPar = new Aula2();
        numeroPar.ValorPar();
        
    }
}