﻿namespace CursoProgramacao
{
    public class Aula2
    {
        int numero;
        int resultado;
        public void ValorPar()
        {
            Console.WriteLine("Digite um numero que deseja perguntar se é par ou impar");
            numero = Convert.ToInt32(Console.ReadLine());

            resultado = numero % 2;

            Console.WriteLine(resultado);

            if( resultado == 0)
            {
                Console.WriteLine("\nEsse numero é par");
            }
            else
            {
                Console.WriteLine("\nEsse numero é impar");
            }          
        }
    }
}
